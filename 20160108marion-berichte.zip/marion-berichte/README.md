cd_collection
=============

This extension is a part of the "Create a custom module" tutorial at [qzminski Blog](http://blog.qzminski.com).

The icon used in the project is made by [FamFamFam](http://famfamfam.com).