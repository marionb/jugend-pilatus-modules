<?php

$GLOBALS['TL_LANG']['tl_downloads']['new'][0] = 'New download';
$GLOBALS['TL_LANG']['tl_downloads']['new'][1] = 'Adding new download';
$GLOBALS['TL_LANG']['tl_downloads']['edit'][0] = 'Editing download';
$GLOBALS['TL_LANG']['tl_downloads']['edit'][1] = 'Editing download';
$GLOBALS['TL_LANG']['tl_downloads']['show'][0] = 'Details';
$GLOBALS['TL_LANG']['tl_downloads']['show'][1] = 'Details of download';
$GLOBALS['TL_LANG']['tl_downloads']['delete'][0] = 'Delete download';
$GLOBALS['TL_LANG']['tl_downloads']['delete'][1] = 'Delete download';

$GLOBALS['TL_LANG']['tl_downloads']['title_legend']= 'Title';
$GLOBALS['TL_LANG']['tl_downloads']['download_legend']= 'More Data';
$GLOBALS['TL_LANG']['tl_downloads']['title']['0'] = 'Download-Title';
$GLOBALS['TL_LANG']['tl_downloads']['title']['1'] = 'Enter the title of the download';
$GLOBALS['TL_LANG']['tl_downloads']['description']['0'] = 'Description of downloads';
$GLOBALS['TL_LANG']['tl_downloads']['description']['1'] = 'Enter the description of the download here';
$GLOBALS['TL_LANG']['tl_downloads']['href']['0'] = 'URL / Path incl. filename';
$GLOBALS['TL_LANG']['tl_downloads']['href']['1'] = 'Enter the URL or the Path to the file including the filename here';
$GLOBALS['TL_LANG']['tl_downloads']['sort_order']['0'] = 'Order of Listing (Integer)';
$GLOBALS['TL_LANG']['tl_downloads']['sort_order']['1'] = 'This value manipulates the order of the downloads in the listing. If different downloads have the same value, the order depends on which is first added.';

?>