<?php
/**
 * Frontend Modul �bersetzungen
 */
$GLOBALS['TL_LANG']['FMD']['meineKategorie']   = 'Meine Kategorie';
$GLOBALS['TL_LANG']['FMD']['meinFrontendModul']= array('Mein Frontend Modul Titel', 'Eine Beschreibung');